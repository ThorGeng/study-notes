from django.apps import AppConfig


class UserManageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'user_manage'
